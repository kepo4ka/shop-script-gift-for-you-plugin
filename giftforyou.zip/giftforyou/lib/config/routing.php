<?php
return [
    "gift/" => 'frontend/gift',
    "gift/get/" => 'frontend/getgift',
    "gift/send/" => 'frontend/sendemail',
];

